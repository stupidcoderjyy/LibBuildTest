;
; Licensed to the Apache Software Foundation (ASF) under one
; or more contributor license agreements.  See the NOTICE file
; distributed with this work for additional information
; regarding copyright ownership.  The ASF licenses this file
; to you under the Apache License, Version 2.0 (the
; "License"); you may not use this file except in compliance
; with the License.  You may obtain a copy of the License at
;
;    http://www.apache.org/licenses/LICENSE-2.0
;
; Unless required by applicable law or agreed to in writing,
; software distributed under the License is distributed on an
; "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
; KIND, either express or implied.  See the License for the
; specific language governing permissions and limitations
; under the License. 
;
MessageId=0x0001
Language=English
Fatal
.
MessageId=0x0002
Language=English
Error
.
MessageId=0x0003
Language=English
Warn
.
MessageId=0x0004
Language=English
Info
.
MessageId=0x0005
Language=English
Debug
.
MessageId=0x1000
Language=English
%1
.
